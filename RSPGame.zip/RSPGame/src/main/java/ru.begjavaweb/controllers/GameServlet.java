package ru.begjavaweb.controllers;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;
import java.util.HashMap;
import java.util.ArrayList;
import ru.begjavaweb.generators.SignGenerator;
import ru.begjavaweb.models.Result;
import ru.begjavaweb.helpers.WinnerFinder;
import ru.begjavaweb.helpers.History;

public class GameServlet extends HttpServlet {


	@Override
	public void doPost(HttpServletRequest req, 
		HttpServletResponse res)
	{
		Result result;
		SignGenerator sg = new SignGenerator();
		History h = new History(req);

		String sign = sg.getGeneratedSign();
		String pick = req.getParameter("pick");

		WinnerFinder wf = new WinnerFinder(pick, sign);
		
		try {
			Result w = wf.getWinner();
			result = w;
			h.addElement(w);
			h.saveHistoryToSession();
		} catch(Exception e) {
			result = new Result(e.getMessage(), pick, sign);
		}
		
		
		redirectResultToClient(req, res, result);
	}

	private void redirectResultToClient(
		HttpServletRequest req,
		HttpServletResponse res,
		Result result) 
	{
		try {
			HttpSession session = req.getSession();
			session.setAttribute("result", result);
			res.sendRedirect("result.jsp");
		} catch (IOException e) {}
	}
}