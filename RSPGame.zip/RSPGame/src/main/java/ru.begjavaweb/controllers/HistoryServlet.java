package ru.begjavaweb.controllers;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class HistoryServlet extends HttpServlet {
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) {
		redirectResultToClient(req, res);
	}

	private void redirectResultToClient(HttpServletRequest req,
										HttpServletResponse res) 
	{
		//HttpSession session = req.getSession();
		try {
			res.sendRedirect("history.jsp");
		} catch(IOException e) {}

	}
}