package ru.begjavaweb.helpers;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.*;
import ru.begjavaweb.models.Result;

public class History {

	private final String historyAttr = "rspHistory";

	private final HttpSession session;

	private List<Result> history = new ArrayList<>();

	public History(final HttpServletRequest req) {
		session = req.getSession();
		Object s = getSessionHistoryAttr();
		if(s == null) {
			saveHistoryToSession();
			s = getSessionHistoryAttr();
		}
		history = (List<Result>)s;
	}

	public void addElement(Result elem) {
		history.add(elem);
	}

	public void saveHistoryToSession() {
		session.setAttribute(historyAttr, history);
	}

	public List<Result> getHistory() {
		return history;
	}

	private Object getSessionHistoryAttr() {
		return session.getAttribute(historyAttr);

	}
}