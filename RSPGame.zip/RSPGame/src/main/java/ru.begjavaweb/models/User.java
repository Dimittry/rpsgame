package ru.begjavaweb.models;

import java.sql.DriverManager;          
import java.sql.Connection;             
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import java.util.HashMap;

public class User {
	
	private final String $tableName = "users";

	private final String email;

	private final String password;

	public User(HashMap<String, String> params)
			throws NoSuchFieldException {
		this.email = verifyParam(params, "email");
		this.password = verifyParam(params, "password");
	}

	public boolean registerUser() throws SQLException{
		boolean flag = false;
		Connection conn = getConnection();
		if(conn == null) {
			return flag;
		}
		PreparedStatement ps = null;
		String sql = "INSERT INTO users (email, password) VALUES (?,?)";
		try {	
			ps = conn.prepareStatement(sql);
			ps.setString(1, email);
			ps.setString(2, password);
			ps.executeUpdate();
			flag = true;
		} catch(SQLException e) {
			System.out.println("Failed register User");
		} finally {
			if(ps != null) {
				ps.close();
			}
			if(conn != null) {
				conn.close();
			}
		}
		return flag;
	}
	/*	
	public ResultSet testConnection() throws SQLException {
			
			PreparedStatement ps = null;
			//String sql = "INSERT INTO users (email, password) VALUES (?,?)";
			String sql = "SELECT * FROM users";
			System.out.println("conn");
			System.out.println(conn);
			//Statement stmt = conn.createStatement();
			ps = conn.prepareStatement(sql);
			//ps.setString(1, email);
			//ps.setString(2, password);
			ResultSet rs =  ps.executeQuery();
			return rs;
	}
	*/

	public String verifyParam(HashMap<String, String> params, 
						String paramName) throws NoSuchFieldException 
	{
		String param = params.get(paramName);
		if(param == null) {
			throw new NoSuchFieldException("Empty field: " + paramName);
		}
		return param;
	}

	private Connection getConnection() {
		String uri = "jdbc:postgresql://localhost/rpsgame";
		Properties props = setLoginForDB("olyver", "SAMBADA1902");
		Connection conn = null;
		try {
			Class.forName("org.postgresql.Driver");
			conn = DriverManager.getConnection(uri, props);
		} 
		catch(ClassNotFoundException e) {
			System.out.println(e);
		}
		catch(SQLException e) {
			System.out.println(e);			
		}
		return conn;
	}

	private Properties setLoginForDB(final String uname, final String passwd) {
		Properties props = new Properties();
		props.setProperty("user", uname);
		props.setProperty("password", passwd);
		return props;
    }
}