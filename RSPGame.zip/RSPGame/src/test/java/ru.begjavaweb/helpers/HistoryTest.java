import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import org.junit.Test;
import java.util.*;
import ru.begjavaweb.helpers.History;
import ru.begjavaweb.models.Result;

public class HistoryTest {

}