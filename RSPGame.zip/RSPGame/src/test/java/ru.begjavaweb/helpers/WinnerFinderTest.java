import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import org.junit.Test;
import java.util.*;
import ru.begjavaweb.helpers.WinnerFinder;
import ru.begjavaweb.models.Result;

public class WinnerFinderTest {
	@Test
	public void testGetWinner() {
		String prResult = "player";
		String srResult = "computer";
		String spResult = "player";

		WinnerFinder wf = new WinnerFinder("scissors", "rock");
		try {
			Result s = wf.getWinner();
			System.out.println("srResult = " + s);
			assertEquals(srResult, s.getWinner());
		} catch(Exception e) {}

		wf = new WinnerFinder("paper", "rock");
		try {
			Result s = wf.getWinner();
			System.out.println("prResult = " + s);
			assertEquals(prResult, s.getWinner());
		} catch(Exception e) {}

		wf = new WinnerFinder("scissors", "paper");
		try {
			Result s = wf.getWinner();
			System.out.println("spResult = " + s);
			assertEquals(spResult, s.getWinner());
		} catch(Exception e) {}

	}
}