import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import org.junit.Test;
import java.util.*;
import ru.begjavaweb.models.User;

import java.sql.ResultSet;
import java.sql.SQLException;


public class UserTest {
	/*
	@Test
	public void testConnection() {
		ResultSet rs = null;
		HashMap<String, String> hp = new HashMap<>();
		hp.put("email", "demar.07@gmail.com");
		hp.put("password", "secret");
		try {
			User u = new User(hp);
			rs = u.testConnection();
			while(rs.next()) {
				System.out.println(rs.getString("email"));
			}
		} catch(NoSuchFieldException e) {
			System.out.println(e);
		}catch(SQLException e) {
			System.out.println(e);
		}
		
		System.out.println("Here");
		System.out.println(rs);
	}
	*/

	@Test
	public void testRegisterUser() {
		boolean res = false;
		HashMap<String, String> hp = new HashMap<>();
		hp.put("email", "demar.07@gmail.com");
		hp.put("password", "secret");
		try {
			User u = new User(hp);
			res = u.registerUser();
		}catch(NoSuchFieldException e) {
			System.out.println(e);
		}catch(SQLException e) {
			System.out.println(e);
		}
		
		System.out.println("Here");
		System.out.println(res);
	}
}

